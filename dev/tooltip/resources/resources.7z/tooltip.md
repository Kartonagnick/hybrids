
class-1.html
------------
img\eukaryota.jpg      : 1-Домен: Эукариоты
img\plant.jpg          : 2-Царство: Растения
img\magnoliophyta.jpg  : 3-Отдел: Цветковые
img\dicotyledones.jpg  : 4-Класс: Двудольные
img\caryophyllales.jpg : 5-Порядок: Гвоздичноцветные
img\aizoaceae.jpg      : 6-Семейство: Аизовые

класс-2.html
------------
img\eukaryota.jpg      : 1-Домен: Эукариоты
img\эукариоты.jpg      : Eukaryota
img\plant.jpg          : 2-Царство: Растения
img\magnoliophyta.jpg  : 3-Отдел: Цветковые
img\dicotyledones.jpg  : 4-Класс: Двудольные
img\caryophyllales.jpg : 5-Порядок: Гвоздичноцветные
img\aizoaceae.jpg      : 6-Семейство: Аизовые
